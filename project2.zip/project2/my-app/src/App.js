import React from "react";
import Product from "./Product";  // Import Product component

function App() {
  return <Product />;  // Directly render Product
}

export default App;
